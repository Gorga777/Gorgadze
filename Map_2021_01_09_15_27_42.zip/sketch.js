var r = 0;
var b = 255;

function setup() {
  createCanvas(600, 400);
  // hue, saturation, and brightness
}

function draw() {
 //background
  r = map(mouseX, 0, 600, 0, 255);
  b - map(mouseX, 0, 600, 255, 0)
  background(r, 0, b);
  // ellipse
  fill(80, 100, 200);
  ellipse(mouseX, 200, 64, 64);
}
  
