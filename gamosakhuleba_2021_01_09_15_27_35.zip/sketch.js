function setup() {
  createCanvas(400, 400);
  background(0);

  stroke(255);
  noFill();
  beginShape();
  
  for (let a = 0; a < 360; a += 10) {
    let x = 100 * sin(a) + 200;
    let y = 100 * cos(a) + 200;
    vertex(x, y);
  }  
  
  // vertex(100, 50);
  // vertex(200, 20);
  // vertex(200, 100);
  // vertex(50, 75);
  // vertex(25, 50);
  endShape();
}
